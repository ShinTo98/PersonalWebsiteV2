
import spUtils from './Utils';

/*-----------------------------------------------
|   Toast [bootstrap 4]
-----------------------------------------------*/
spUtils.$document.ready(() => {
  $('.toast').toast();
});
